package com.telusko;

public class purchase {
 String poNumber;
 String lineNumber;
 String materialCode;
 String orderQuantity;
 String shippedQuantity;
 String receivedQuantity;
 String requiredQuantity;
 String availableQuantity;
 String uop;
 String deliveryDate;
 String creationDate;
 String price;
 String currency;
 String supplier;
 String manufacturer;
 String orderStatus;
public String getPoNumber() {
	return poNumber;
}
public void setPoNumber(String poNumber) {
	this.poNumber = poNumber;
}
public String getLineNumber() {
	return lineNumber;
}
public void setLineNumber(String lineNumber) {
	this.lineNumber = lineNumber;
}
public String getMaterialCode() {
	return materialCode;
}
public void setMaterialCode(String materialCode) {
	this.materialCode = materialCode;
}
public String getOrderQuantity() {
	return orderQuantity;
}
public void setOrderQuantity(String orderQuantity) {
	this.orderQuantity = orderQuantity;
}
public String getShippedQuantity() {
	return shippedQuantity;
}
public void setShippedQuantity(String shippedQuantity) {
	this.shippedQuantity = shippedQuantity;
}
public String getReceivedQuantity() {
	return receivedQuantity;
}
public void setReceivedQuantity(String receivedQuantity) {
	this.receivedQuantity = receivedQuantity;
}
public String getRequiredQuantity() {
	return requiredQuantity;
}
public void setRequiredQuantity(String requiredQuantity) {
	this.requiredQuantity = requiredQuantity;
}
public String getAvailableQuantity() {
	return availableQuantity;
}
public void setAvailableQuantity(String availableQuantity) {
	this.availableQuantity = availableQuantity;
}
public String getUop() {
	return uop;
}
public void setUop(String uop) {
	this.uop = uop;
}
public String getDeliveryDate() {
	return deliveryDate;
}
public void setDeliveryDate(String deliveryDate) {
	this.deliveryDate = deliveryDate;
}
public String getCreationDate() {
	return creationDate;
}
public void setCreationDate(String creationDate) {
	this.creationDate = creationDate;
}
public String getPrice() {
	return price;
}
public void setPrice(String price) {
	this.price = price;
}
public String getCurrency() {
	return currency;
}
public void setCurrency(String currency) {
	this.currency = currency;
}
public String getSupplier() {
	return supplier;
}
public void setSupplier(String supplier) {
	this.supplier = supplier;
}
public String getManufacturer() {
	return manufacturer;
}
public void setManufacturer(String manufacturer) {
	this.manufacturer = manufacturer;
}
public String getOrderStatus() {
	return orderStatus;
}
public void setOrderStatus(String orderStatus) {
	this.orderStatus = orderStatus;
}
}
